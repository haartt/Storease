import SwiftUI
import SwiftData

/// Bottom-sheet file browser used by `StartScreenView`.
/// Contains two internal tabs:
/// - Recents: grid of recent stories
/// - Browse: full library list
struct StoryFileBrowserView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SavedStory.createdAt, order: .reverse) private var stories: [SavedStory]
    
    /// Called when the user taps a story in Recents / Browse.
    let onSelectStory: (SavedStory) -> Void
    
    enum Tab: Int {
        case recents
        case browse
    }
    
    @State private var selectedTab: Tab = .recents
    
    private var recentStories: [SavedStory] {
        Array(stories.prefix(12))
    }
    
    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {
                // Recents tab
                RecentStoriesGridView(stories: recentStories, onSelect: onSelectStory)
                    .tabItem {
                        Label("Recents", systemImage: "clock.fill")
                    }
                    .tag(Tab.recents)

                // Browse tab
                LibraryStoriesListView(stories: stories, onSelect: onSelectStory)
                    .tabItem {
                        Label("Browse", systemImage: "folder.fill")
                    }
                    .tag(Tab.browse)
            }
            .tabViewStyle(.automatic)
            .background(.ultraThinMaterial) // glassy floating effect
            .navigationTitle("Stories")
            .navigationBarTitleDisplayMode(.automatic)
        }
    }
}

// MARK: - Recents Grid

/// Shows the most recently created stories in a 3-column grid.
struct RecentStoriesGridView: View {
    let stories: [SavedStory]
    let onSelect: (SavedStory) -> Void
    
    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        if stories.isEmpty {
            VStack(spacing: 8) {
                Text("No recent stories")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(stories) { story in
                        StoryFileItemView(story: story)
                            .onTapGesture {
                                onSelect(story)
                            }
                    }
                }
                .padding()
            }
        }
    }
}

// MARK: - Library List (Browse Tab)

/// Simple library list using `StoryFileItemView` in a single-column list.
/// Backed by SwiftData (`stories` passed in from the browser).
struct LibraryStoriesListView: View {
    let stories: [SavedStory]
    let onSelect: (SavedStory) -> Void
    
    var body: some View {
        if stories.isEmpty {
            VStack(spacing: 8) {
                Text("No stories")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            List {
                ForEach(stories) { story in
                    StoryFileItemView(story: story)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            onSelect(story)
                        }
                        .listRowBackground(Color.clear)
                }
            }
            .listStyle(.insetGrouped)
        }
    }
}


#Preview {
    StoryFileBrowserView { _ in }
        .modelContainer(for: SavedStory.self, inMemory: true)
}

//
//  StoryFileBrowserView.swift
//  Storease
//
//  Created by Fabio Antonucci on 19/12/25.
//
